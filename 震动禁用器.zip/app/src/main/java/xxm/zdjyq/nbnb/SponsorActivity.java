package xxm.zdjyq.nbnb;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 赞助支持：两张图片横向排列，各自等比缩放，
 * 横屏时也能完整显示、不需要上下滑动；右上角 X 退出。
 */
public class SponsorActivity extends Activity {

    private static final String URL_1 =
            "https://www.picmo.cn/uploads/20261012/51c84173b132992717afe1e4da9dc671.jpg";
    private static final String URL_2 =
            "https://www.picmo.cn/uploads/20261012/dec4c5c8869bd44cc382bc16cbca2b51.png";

    private ImageView iv1;
    private ImageView iv2;
    private TextView tvHint;

    private int loaded = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsor);

        iv1 = (ImageView) findViewById(R.id.iv_sponsor1);
        iv2 = (ImageView) findViewById(R.id.iv_sponsor2);
        tvHint = (TextView) findViewById(R.id.tv_sponsor_hint);

        findViewById(R.id.btn_sponsor_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        load(URL_1, iv1, "sponsor1");
        load(URL_2, iv2, "sponsor2");
    }

    private void load(final String url, final ImageView target, final String cacheName) {
        final File cache = new File(getCacheDir(), cacheName);
        // 先尝试本地缓存
        Bitmap cached = decodeFile(cache);
        if (cached != null) {
            target.setImageBitmap(cached);
            onOneLoaded(null);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                String error = null;
                InputStream in = null;
                FileOutputStream out = null;
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(12000);
                    conn.setInstanceFollowRedirects(true);
                    conn.connect();
                    in = conn.getInputStream();
                    out = new FileOutputStream(cache);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                    }
                    out.flush();
                    bitmap = decodeFile(cache);
                } catch (Throwable t) {
                    error = t.getClass().getSimpleName();
                } finally {
                    close(in);
                    close(out);
                }

                final Bitmap result = bitmap;
                final String err = error;
                target.post(new Runnable() {
                    @Override
                    public void run() {
                        if (result != null) {
                            target.setImageBitmap(result);
                        }
                        onOneLoaded(err);
                    }
                });
            }
        }).start();
    }

    private void onOneLoaded(String error) {
        loaded++;
        if (loaded < 2) {
            return;
        }
        tvHint.setVisibility(error == null ? View.GONE : View.VISIBLE);
        if (error != null) {
            tvHint.setText("图片加载失败（" + error + "），请检查网络");
        }
    }

    private Bitmap decodeFile(File f) {
        try {
            if (f != null && f.exists() && f.length() > 0) {
                return BitmapFactory.decodeFile(f.getAbsolutePath());
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private void close(java.io.Closeable c) {
        try {
            if (c != null) {
                c.close();
            }
        } catch (Throwable ignored) {
        }
    }
}