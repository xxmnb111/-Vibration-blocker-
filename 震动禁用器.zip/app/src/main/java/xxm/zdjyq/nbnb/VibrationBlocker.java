package xxm.zdjyq.nbnb;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

/**
 * 免 Root 版核心：通过「系统设置」开关系统级震动。
 *
 * 设计要点（解决"关闭后还是无法震动"）：
 *
 *  1. **状态直接从系统读取**，不再依赖 App 自己的 SharedPreferences。
 *     以前 AIDE 重装会清空 App 数据，但系统里的 0 还在 —— 结果按钮以为自己是"关闭"状态，
 *     再按一下却是"再次关闭"，系统永远回不来。现在按钮显示的状态由系统实际值决定，
 *     即使重装过也能正确显示，并且一按就能真正恢复。
 *
 *  2. **"关闭拦截器"= 强制打开震动**。老代码是"写回记录的原值"，可如果当初记录到的原值
 *     本身就是 0（比如上一次没恢复干净），那"恢复"等于继续关闭，永远震不了。
 *     现在恢复时直接把震动相关开关写成 1（开），并处理掉会把震感压到极低的强度键。
 *
 *  3. 只动设备上**真实存在**的设置键，不凭空创建键。
 *
 *  4. 启动时自动做一次 sanitize()：清理老版本遗留的数据、修正被写坏的强度值。
 */
public class VibrationBlocker {

    /** 老版本遗留的 SharedPreferences（只用来清理） */
    private static final String PREF = "vibration_blocker_prefs";
    private static final String P_LEGACY_PREFIX = "old_";
    private static final String P_ENABLED = "enabled";
    private static final String P_EXIST = "exists_";
    private static final String P_VALUE = "value_";

    /** 判断"是否处于关闭震动状态"用的关键开关 */
    private static final String[] CORE_KEYS = {
            "haptic_feedback_enabled",   // 触感反馈（按键/长按/输入法）
            "vibrate_when_ringing",      // 来电震动
            "vibrate_in_silent"          // 静音时震动
    };

    /** 一起跟着写的其它开关 */
    private static final String[] OTHER_KEYS = {
            "vibrate_on"                 // 震动总开关（部分机型有效）
    };

    /** 触感强度：值被写成 0/1 会让震感几乎消失，恢复时要处理 */
    public static final String KEY_INTENSITY = "haptic_feedback_intensity";

    // ==================== 状态：直接读系统 ====================

    /**
     * 系统震动当前是否处于"被关闭"状态（按钮文字/图标就是按这个显示的）。
     *
     * 优先看触感反馈总开关，其次看来电震动+静音震动两个是否都关，
     * 最后才退回 App 自己的记录。这样即使某个键被 ROM 拒绝写入，
     * 状态判断也不会失真。
     */
    public static boolean isBlocked(Context c) {
        String haptic = rawValue(c, "haptic_feedback_enabled");
        if (haptic != null) {
            return parseInt(haptic, 1) == 0;
        }
        String ringing = rawValue(c, "vibrate_when_ringing");
        String silent = rawValue(c, "vibrate_in_silent");
        if (ringing != null && silent != null) {
            return parseInt(ringing, 1) == 0 && parseInt(silent, 1) == 0;
        }
        String vibrateOn = rawValue(c, "vibrate_on");
        if (vibrateOn != null) {
            return parseInt(vibrateOn, 1) == 0;
        }
        return prefs(c).getBoolean(P_ENABLED, false);
    }

    /** 兼容命名：是否处于关闭拦截状态 */
    public static boolean isEnabled(Context c) {
        return isBlocked(c);
    }

    // ==================== 权限 ====================

    private static boolean canWriteRaw(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Settings.System.canWrite(c);
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** canWrite() 不准的 ROM 上，用"原样写回"探测一次真实写入能力 */
    public static boolean hasWriteAccess(Context c) {
        if (canWriteRaw(c)) {
            return true;
        }
        try {
            String raw = rawValue(c, "haptic_feedback_enabled");
            if (raw == null) {
                return false;
            }
            return Settings.System.putInt(c.getContentResolver(),
                    "haptic_feedback_enabled", parseInt(raw, 1));
        } catch (Throwable t) {
            return false;
        }
    }

    // ==================== 开关 ====================

    /** 关闭系统震动：只写设备上真实存在的键 */
    public static void disable(Context c) {
        for (String key : allKeys()) {
            if (rawValue(c, key) == null) {
                continue; // 设备上没有这个键，不去创建
            }
            write(c, key, 0);
        }
        prefs(c).edit().putBoolean(P_ENABLED, true).commit();
    }

    /**
     * 恢复震动：把震动开关全部写成 1（这才是"恢复震动"应有的结果），
     * 并处理会被压到极低的触感强度键。
     */
    public static void restore(Context c) {
        for (String key : allKeys()) {
            if (rawValue(c, key) == null) {
                continue;
            }
            if (KEY_INTENSITY.equals(key)) {
                // 强度键不写 1（1 ≈ 没有震动），直接删掉让系统用默认强度
                int now = readInt(c, key, -1);
                if (now >= 0 && now <= 1) {
                    delete(c, key);
                }
                continue;
            }
            write(c, key, 1);
        }
        prefs(c).edit().putBoolean(P_ENABLED, false).commit();
    }

    /**
     * 启动时调用：清理老版本遗留数据 + 修正被写坏的强度值。
     * 返回 true 表示确实改动了系统设置。
     */
    public static boolean sanitize(Context c) {
        boolean changed = false;
        SharedPreferences sp = prefs(c);

        // 1. 触感强度被写成 0/1（旧版本兜底值）→ 删掉，恢复默认强度
        String raw = rawValue(c, KEY_INTENSITY);
        if (raw != null) {
            int now = parseInt(raw, -1);
            if (now >= 0 && now <= 1) {
                changed = delete(c, KEY_INTENSITY);
            }
        }

        // 2. 清掉老版本记录（exists_/value_/old_ 都不再需要了）
        for (String name : sp.getAll().keySet().toArray(new String[0])) {
            if (name.startsWith(P_LEGACY_PREFIX)
                    || name.startsWith(P_EXIST)
                    || name.startsWith(P_VALUE)) {
                sp.edit().remove(name).commit();
            }
        }
        return changed;
    }

    // ==================== 工具 ====================

    private static String[] allKeys() {
        String[] all = new String[CORE_KEYS.length + OTHER_KEYS.length + 1];
        System.arraycopy(CORE_KEYS, 0, all, 0, CORE_KEYS.length);
        System.arraycopy(OTHER_KEYS, 0, all, CORE_KEYS.length, OTHER_KEYS.length);
        all[all.length - 1] = KEY_INTENSITY;
        return all;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** 返回设置项原始字符串；键不存在返回 null */
    private static String rawValue(Context c, String key) {
        try {
            return Settings.System.getString(c.getContentResolver(), key);
        } catch (Throwable t) {
            return null;
        }
    }

    private static int readInt(Context c, String key, int def) {
        try {
            return Settings.System.getInt(c.getContentResolver(), key, def);
        } catch (Throwable t) {
            return def;
        }
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static void write(Context c, String key, int value) {
        try {
            Settings.System.putInt(c.getContentResolver(), key, value);
        } catch (Throwable ignored) {
        }
    }

    /** 删除设置项（传 null 即删除），让系统回落到默认值 */
    private static boolean delete(Context c, String key) {
        try {
            return Settings.System.putString(c.getContentResolver(), key, null);
        } catch (Throwable t) {
            return false;
        }
    }
}