package xxm.zdjyq.nbnb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * 主界面：
 *  1. 悬浮开关按钮（关闭震动时显示「运行中」，震动可用时显示「开启」）
 *  2. 扁长方形「测试震动」按钮
 *  3. 任务完成提示（应用内提示，不是系统通知）
 *  4. 简约文本「给予权限」
 * 右上角的大齿轮进入设置。
 *
 * 注意：按钮状态由**系统实际设置**决定，不再依赖 App 自己的记录，
 *      所以重装应用后也不会出现"显示已关闭但其实系统还关着"的情况。
 */
public class MainActivity extends Activity {

    private ImageView ivStateIcon;
    private TextView tvStateText;
    private View alertDone;
    private TextView tvDoneTitle;
    private TextView tvDoneDesc;
    private TextView tvGrant;

    private final Runnable hideAlertTask = new Runnable() {
        @Override
        public void run() {
            if (alertDone != null) {
                alertDone.setVisibility(View.INVISIBLE);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivStateIcon = (ImageView) findViewById(R.id.iv_state_icon);
        tvStateText = (TextView) findViewById(R.id.tv_state_text);
        alertDone = findViewById(R.id.alert_done);
        tvDoneTitle = (TextView) findViewById(R.id.tv_done_title);
        tvDoneDesc = (TextView) findViewById(R.id.tv_done_desc);
        tvGrant = (TextView) findViewById(R.id.tv_grant);

        findViewById(R.id.btn_toggle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle();
            }
        });

        findViewById(R.id.btn_test).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testVibration();
            }
        });

        findViewById(R.id.btn_settings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        findViewById(R.id.btn_alert_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDone.setVisibility(View.INVISIBLE);
            }
        });

        tvGrant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWriteSettingsPage();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 修正被老版本写坏的触感强度 / 清理老数据
        if (VibrationBlocker.sanitize(this)) {
            showDone("已修复震感设置", "被写坏的强度值已还原，点「测试震动」试试");
        }
        refresh();
    }

    private void toggle() {
        if (!VibrationBlocker.hasWriteAccess(this)) {
            showDone("需要权限", "请先点击下方「给予权限」");
            return;
        }

        boolean wasBlocked = VibrationBlocker.isBlocked(this);
        if (wasBlocked) {
            VibrationBlocker.restore(this);   // 把震动打开
        } else {
            VibrationBlocker.disable(this);   // 关掉震动
        }
        refresh();

        // 写完再看一次系统真实状态，确认是否生效
        boolean nowBlocked = VibrationBlocker.isBlocked(this);
        if (nowBlocked == wasBlocked) {
            showDone("未能生效", "系统拒绝了写入，请在系统设置里手动打开震动");
        } else if (nowBlocked) {
            showDone("任务完成", "已关闭所有震动");
        } else {
            showDone("任务完成", "震动已打开，可点「测试震动」确认");
        }
    }

    /** 测试震动：直接调系统震动器（不受触感反馈开关影响） */
    private void testVibration() {
        Vibrator vibrator = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                android.os.VibratorManager manager =
                        (android.os.VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (manager != null) {
                    vibrator = manager.getDefaultVibrator();
                }
            } else {
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            }
        } catch (Throwable ignored) {
        }

        if (vibrator == null || !vibrator.hasVibrator()) {
            showDone("无法震动", "设备没有震动马达或已被系统禁用");
            return;
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(300);
            }
            showDone("测试震动", "手机会震一下，感觉到了吗？");
        } catch (Throwable t) {
            showDone("测试失败", t.getClass().getSimpleName());
        }
    }

    /** 应用内任务完成提示，3.5 秒后自动消失，也可以点右边的 X 关掉 */
    private void showDone(String title, String desc) {
        tvDoneTitle.setText(title);
        tvDoneDesc.setText(desc);
        alertDone.setVisibility(View.VISIBLE);
        alertDone.removeCallbacks(hideAlertTask);
        alertDone.postDelayed(hideAlertTask, 3500);
    }

    private void openWriteSettingsPage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
                return;
            } catch (Throwable ignored) {
            }
        }
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        } catch (Throwable ignored) {
        }
    }

    private void refresh() {
        boolean blocked = VibrationBlocker.isBlocked(this);
        // 关着震动时显示带红线的图标；震动可用时显示普通图标
        ivStateIcon.setImageResource(blocked ? R.drawable.ic_vibrate_red : R.drawable.ic_vibrate_plain);
        tvStateText.setText(blocked ? "运行中" : "开启");
        tvGrant.setVisibility(VibrationBlocker.hasWriteAccess(this) ? View.GONE : View.VISIBLE);
    }
}